package com.example.intelligenthospitalsuggestionbox;

public class post {
    private String commenT, Hospital, Department, Date;

    public post() {

    }

    public post(String commenT, String hospital, String department, String date) {
        this.commenT = commenT;
        this.Hospital = hospital;
        this.Department = department;
        this.Date = date;


    }

    public String getCommenT() {
        return commenT;
    }

    public String getHospital() {
        return Hospital;
    }

    public String getDepartment() {
        return Department;
    }
    public String getDate() {
        return Date;
    }
}
