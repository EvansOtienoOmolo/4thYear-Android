package com.example.intelligenthospitalsuggestionbox;

import android.app.DatePickerDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    public static final String TAG = "MainActivity";
    private TextView mDIsplayDate;
    private DatePickerDialog.OnDateSetListener mDateSetLister;
    private static final int RESULT_LOAD_IMAGE = 1;

    EditText commentText;
    Spinner Spinner1, Spinner3;
    Button Submit_bt;
    TextView tvDate;



    ImageView imageToUpload;
    Button bUploadImage;
    EditText uploadImageName;

    //Firebase
    DatabaseReference databasepost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Declaring widgets to be posted in firebase
        commentText = (EditText) findViewById(R.id.commentText);
        Spinner1 = (Spinner) findViewById(R.id.spinner1);
        Spinner3 = (Spinner) findViewById(R.id.spinner3);
        Submit_bt = (Button) findViewById(R.id.Submit_bt);
        tvDate = (TextView) findViewById(R.id.tvDate);


        //firebaseDatabase = FirebaseDatabase.getInstance();
       // databaseReference = firebaseDatabase.getReference();
        databasepost = FirebaseDatabase.getInstance().getReference();

        Submit_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                postcomment();
            }
        });


        //Declaring Image items button image view and edit text
        imageToUpload = (ImageView) findViewById(R.id.imageToUpload);
        bUploadImage = (Button) findViewById(R.id.bUploadImage);
        uploadImageName = (EditText) findViewById(R.id.uploadImageName);

        imageToUpload.setOnClickListener(this);
        bUploadImage.setOnClickListener(this);


        //Declaring date textview
        mDIsplayDate = (TextView) findViewById(R.id.tvDate);

        mDIsplayDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(MainActivity.this, android.R.style.Theme_Holo_Dialog_MinWidth,
                        mDateSetLister, year, month, day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();



            }
        });

        //Initializing on date set listener
        mDateSetLister = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month + 1;
                Log.d(TAG, "onDateSet: dd/mm/yyy: " + dayOfMonth + "/" + month +"/" + year );

                String date = dayOfMonth + "/" + month +"/" + year;
                mDIsplayDate.setText(date);

            }
        };


        //Drop down spinners
        Spinner mySpinner = (Spinner) findViewById(R.id.spinner1);

        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(MainActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.hospitals));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(myAdapter);


        Spinner mySpinner3 = (Spinner) findViewById(R.id.spinner3);
        ArrayAdapter<String> myAdapter3 = new ArrayAdapter<String>(MainActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.department));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner3.setAdapter(myAdapter3);
    }



    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.imageToUpload:
                Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(galleryIntent, RESULT_LOAD_IMAGE);

                break;
            case R.id.bUploadImage:

                break;
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri selectImage = data.getData();
            imageToUpload.setImageURI(selectImage);
        }
    }

    private void postcomment() {
        String commenT = commentText.getText().toString();
        String Hospital = Spinner1.getSelectedItem().toString();
        String Department = Spinner3.getSelectedItem().toString();
        String Date = tvDate.getText().toString();

        if(!TextUtils.isEmpty(commenT)){

           // databaseReference.push();
            String id = databasepost.push().getKey();
            post Post = new post(commenT, Hospital, Department, Date);

            databasepost.child(id).setValue(Post);
            databasepost.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Toast.makeText(MainActivity.this, "Thank you for leaving your suggestion", Toast.LENGTH_SHORT).show();

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(MainActivity.this, "Error..!!" +databaseError, Toast.LENGTH_SHORT).show();

                }
            });



        }else{
            Toast.makeText(this, "Please Leave your comment", Toast.LENGTH_SHORT).show();
        }


    }
}
